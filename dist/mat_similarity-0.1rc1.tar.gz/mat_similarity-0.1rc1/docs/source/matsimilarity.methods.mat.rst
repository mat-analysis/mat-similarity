matsimilarity.methods.mat package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matsimilarity.methods.mat.EDR
   matsimilarity.methods.mat.LCSS
   matsimilarity.methods.mat.MSM
   matsimilarity.methods.mat.MUITAS

Module contents
---------------

.. automodule:: matsimilarity.methods.mat
   :members:
   :undoc-members:
   :show-inheritance:
