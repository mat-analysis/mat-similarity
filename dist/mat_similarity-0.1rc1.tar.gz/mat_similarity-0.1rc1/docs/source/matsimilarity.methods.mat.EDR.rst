matsimilarity.methods.mat.EDR package
=====================================

Submodules
----------

matsimilarity.methods.mat.EDR.EDR\_T2T module
---------------------------------------------

.. automodule:: matsimilarity.methods.mat.EDR.EDR_T2T
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: matsimilarity.methods.mat.EDR
   :members:
   :undoc-members:
   :show-inheritance:
