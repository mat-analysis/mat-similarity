matsimilarity.methods package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matsimilarity.methods.mat

Module contents
---------------

.. automodule:: matsimilarity.methods
   :members:
   :undoc-members:
   :show-inheritance:
