matsimilarity.methods.mat.MSM namespace
=======================================

.. py:module:: matsimilarity.methods.mat.MSM

Submodules
----------

matsimilarity.methods.mat.MSM.MSM\_T2T module
---------------------------------------------

.. automodule:: matsimilarity.methods.mat.MSM.MSM_T2T
   :members:
   :undoc-members:
   :show-inheritance:
