matsimilarity.core package
==========================

Submodules
----------

matsimilarity.core.SimilarityMeasure module
-------------------------------------------

.. automodule:: matsimilarity.core.SimilarityMeasure
   :members:
   :undoc-members:
   :show-inheritance:

matsimilarity.core.utils module
-------------------------------

.. automodule:: matsimilarity.core.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: matsimilarity.core
   :members:
   :undoc-members:
   :show-inheritance:
