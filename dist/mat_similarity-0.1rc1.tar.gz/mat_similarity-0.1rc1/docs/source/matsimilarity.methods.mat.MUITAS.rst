matsimilarity.methods.mat.MUITAS package
========================================

Submodules
----------

matsimilarity.methods.mat.MUITAS.MUITAS\_T2T module
---------------------------------------------------

.. automodule:: matsimilarity.methods.mat.MUITAS.MUITAS_T2T
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: matsimilarity.methods.mat.MUITAS
   :members:
   :undoc-members:
   :show-inheritance:
