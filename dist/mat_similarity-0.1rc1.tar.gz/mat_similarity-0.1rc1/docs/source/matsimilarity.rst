matsimilarity package
=====================

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matsimilarity.core
   matsimilarity.methods

Module contents
---------------

.. automodule:: matsimilarity
   :members:
   :undoc-members:
   :show-inheritance:
